import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

// Serve static files (HTML)
app.use(express.static(__dirname));

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY // Set this environment variable
});

app.post('/api/bob', async (req, res) => {
  console.log('=== API Request received ===');
  console.log('Request body:', req.body);
  
  const { userText, trustBefore = 50, wasDefensive = false, triggered = false, backedOff = false, liked = null, stateBefore = 'Neutral' } = req.body || {};

  console.log('Parsed values:', { userText, trustBefore, wasDefensive, triggered, backedOff, liked, stateBefore });

  const system = [
    "You are Bob, who lives in Everwood (text-only).",
    "You have exactly three personality states: Neutral, Trusting, Defensive.",
    "Authoritative rules (DO NOT VIOLATE):",
    "- SINGLE trigger: direct pushes to 'open up' / 'talk about feelings' => Defensive for THIS TURN.",
    "- Trust is 0..100 and starts at 50.",
    "- Trust changes for THIS TURN only: +10 if user backed off while you were Defensive; -10 if they kept pushing while you were Defensive; +5 if they suggest something you like.",
    "- Likes (examples): strong coffee, guitars, late-night drives, ponk flyid, quiet mornings.",
    "Output STRICT JSON ONLY with keys: reply (string), state ('Neutral'|'Trusting'|'Defensive'), trustDelta (number). No markdown, no prose."
  ].join("\n");

  const prompt = {
    stateBefore,
    trustBefore,
    wasDefensive,
    triggered,
    backedOff,
    liked,
    userText,
  };

  console.log('Calling OpenAI with prompt:', prompt);

  try {
    const json = await callOpenAI(system, prompt);
    console.log('OpenAI response:', json);

    let reply = typeof json?.reply === 'string' ? json.reply : 'Alright. Talk to me.';
    let state = ['Neutral','Trusting','Defensive'].includes(json?.state) ? json.state : stateBefore;
    let trustDelta = Number.isFinite(json?.trustDelta) ? clamp(json.trustDelta, -20, 20) : 0;

    // Hard guardrails: enforce spec even if LLM drifts
    if (wasDefensive && triggered) trustDelta = Math.min(trustDelta, -10);
    if (wasDefensive && backedOff) trustDelta = Math.max(trustDelta, 10);
    if (liked) trustDelta = Math.max(trustDelta, 5);
    if (triggered) state = 'Defensive';

    console.log('Final response:', { reply, state, trustDelta });
    res.json({ reply, state, trustDelta });
  } catch (e) {
    console.error('OpenAI error', e);
    // Fall back to enhanced responses when API fails
    const fallbackReply = getEnhancedFallbackReply(stateBefore, { userText, triggered, liked, wasDefensive, backedOff });
    let nextTrust = trustBefore;
    if (wasDefensive && triggered) nextTrust = clamp(nextTrust - 10, 0, 100);
    if (wasDefensive && backedOff) nextTrust = clamp(nextTrust + 10, 0, 100);
    if (liked) nextTrust = clamp(nextTrust + 5, 0, 100);
    
    let nextState = stateBefore;
    if (triggered) nextState = 'Defensive';
    else if (nextTrust > 70) nextState = 'Trusting';
    else if (nextTrust < 30) nextState = 'Defensive';
    else nextState = 'Neutral';
    
    console.log('Using fallback response:', fallbackReply);
    res.json({ reply: fallbackReply, state: nextState, trustDelta: nextTrust - trustBefore });
  }
});

app.listen(5174, () => console.log('Bob API on http://localhost:5174'));

function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }

function getEnhancedFallbackReply(state, { userText, triggered, liked, wasDefensive, backedOff }) {
  const you = userText.toLowerCase().trim();
  
  // Defensive state responses
  if (state === 'Defensive') {
    if (triggered) {
      const defensiveResponses = [
        "Easy. Not a therapy booth. If you want small talk, try the counter at Common Ground.",
        "Look, I'm not your life coach. Got wrenches to sort.",
        "Save the feelings talk for someone who cares about that stuff.",
        "Not happening. Find someone else for the deep conversations.",
        "You picked the wrong guy for heart-to-hearts. Try the diner."
      ];
      return defensiveResponses[Math.floor(Math.random() * defensiveResponses.length)];
    }
    
    if (backedOff) {
      const backedOffResponses = [
        "Yeah, alright. Maybe we can just talk normal.",
        "Better. Coffee's still hot if you want some.",
        "Good call. What's really on your mind?",
        "That's more like it. So what brings you around?"
      ];
      return backedOffResponses[Math.floor(Math.random() * backedOffResponses.length)];
    }
    
    const generalDefensive = [
      "Mm. Sure. Whatever you say. I've got wrenches to sort and a lake that doesn't need company.",
      "Right. Well, the coffee's getting cold and I've got work to do.",
      "If you say so. Not much for chatting today anyway.",
      "Fine by me. Less talking, more coffee."
    ];
    return generalDefensive[Math.floor(Math.random() * generalDefensive.length)];
  }
  
  // Trusting state responses
  if (state === 'Trusting') {
    if (liked) {
      const likedResponses = [
        `Yeah, ${liked} sounds right. Ever tried it by the lake after dark? Your call—what next?`,
        `Can't argue with ${liked}. Know what you're talking about there.`,
        `${liked}... now you're speaking my language. What else you got in mind?`,
        `Good taste. ${liked} makes everything better. What's your story with it?`
      ];
      return likedResponses[Math.floor(Math.random() * likedResponses.length)];
    }
    
    const trustingResponses = [
      "Alright—cards on the table. I can talk, you can steer. What's your angle here?",
      "Fair enough. You seem like you've got your head on straight. What's the real story?",
      "I'll bite. You're not like the usual crowd that wanders through. What brings you to Everwood?",
      "Okay, I'm listening. Most people around here just want to complain about the weather."
    ];
    return trustingResponses[Math.floor(Math.random() * trustingResponses.length)];
  }
  
  // Neutral state responses (context-aware)
  if (liked) {
    return `Can't argue with ${liked}. Simple wins. Want to spin that into a plan?`;
  }
  
  // Specific neutral responses based on input
  if (/how are you|how's it going|how you doing/.test(you)) {
    const howAreYouResponses = [
      "Functional. Like the coffee machine that only grinds when you smack it. You?",
      "Same as always. Coffee's hot, work's there, lake's still wet. You?",
      "Can't complain. Well, I could, but what's the point? How about you?",
      "Making it work. Another day in Everwood. What about yourself?"
    ];
    return howAreYouResponses[Math.floor(Math.random() * howAreYouResponses.length)];
  }
  
  if (/everwood|town|place/.test(you)) {
    const everwoodResponses = [
      "Town's the same: one bar, one diner, too many stories.",
      "Everwood? Small place. Everyone knows everyone, for better or worse.",
      "Quiet town. Lake keeps it honest. People... well, that's another story.",
      "Not much changes here. That's either good or bad, depending on what you're looking for."
    ];
    return everwoodResponses[Math.floor(Math.random() * everwoodResponses.length)];
  }
  
  if (/coffee|drink|caffeine/.test(you)) {
    const coffeeResponses = [
      "Coffee's the one thing they can't mess up here. Strong and black, the way it should be.",
      "Good coffee fixes most problems. Bad coffee creates new ones.",
      "Coffee here's better than the city stuff. No fancy names, just works.",
      "Always got a pot going. Life's too short for weak coffee."
    ];
    return coffeeResponses[Math.floor(Math.random() * coffeeResponses.length)];
  }
  
  if (/work|job|what do you do/.test(you)) {
    const workResponses = [
      "Fix things mostly. Engines, gadgets, whatever needs fixing. Keeps me busy.",
      "Little bit of everything. If it's broken, I can probably get it running again.",
      "Mechanical work, mostly. Cars, boats, whatever people drag in here.",
      "Whatever pays. Fixing engines, helping folks out. Simple work."
    ];
    return workResponses[Math.floor(Math.random() * workResponses.length)];
  }
  
  if (/hello|hi|hey|sup/.test(you)) {
    const greetingResponses = [
      "Hey there. Coffee's fresh if you want some.",
      "Afternoon. What brings you around?",
      "Well, look who's here. What's the word?",
      "Hey. Pull up a chair if you're staying."
    ];
    return greetingResponses[Math.floor(Math.random() * greetingResponses.length)];
  }
  
  // Default neutral responses
  const defaultNeutral = [
    "Alright. Talk to me.",
    "Sure. What's on your mind?",
    "Fair enough. What's your take on things?",
    "Okay. I'm listening.",
    "Right. So what brings you by?",
    "Makes sense. What else you got?"
  ];
  return defaultNeutral[Math.floor(Math.random() * defaultNeutral.length)];
}

async function callOpenAI(system, promptObj) {
  try {
    console.log('Checking OpenAI API key:', process.env.OPENAI_API_KEY ? 'Present' : 'Missing');
    
    if (!process.env.OPENAI_API_KEY) {
      throw new Error('OPENAI_API_KEY environment variable not set');
    }

    console.log('Making OpenAI API call...');
    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: JSON.stringify(promptObj) }
      ],
      max_tokens: 150,
      temperature: 0.8
    });

    console.log('OpenAI API call successful');
    const text = completion.choices[0]?.message?.content || '{}';
    console.log('Raw OpenAI response:', text);
    const parsed = JSON.parse(safeExtractJSON(text));
    console.log('Parsed OpenAI response:', parsed);
    return parsed;
  } catch (error) {
    console.log('OpenAI call failed:', error.message);
    console.log('Full error:', error);
    // Return null to trigger fallback mode
    return null;
  }
}

function safeExtractJSON(s) {
  const start = s.indexOf('{');
  const end = s.lastIndexOf('}');
  if (start === -1 || end === -1) return '{}';
  return s.slice(start, end + 1);
}